﻿namespace Snake
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("Имя", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup2 = new System.Windows.Forms.ListViewGroup("Результат", System.Windows.Forms.HorizontalAlignment.Left);
            this.panel1 = new System.Windows.Forms.Panel();
            this.leaderBoard = new System.Windows.Forms.ListView();
            this.leadersButton = new System.Windows.Forms.Button();
            this.loadManager = new System.Windows.Forms.RichTextBox();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(161)))), ((int)(((byte)(94)))));
            this.panel1.Controls.Add(this.leaderBoard);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(376, 411);
            this.panel1.TabIndex = 0;
            // 
            // leaderBoard
            // 
            this.leaderBoard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(161)))), ((int)(((byte)(94)))));
            this.leaderBoard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.leaderBoard.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.leaderBoard.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.leaderBoard.ForeColor = System.Drawing.SystemColors.Info;
            listViewGroup1.Header = "Имя";
            listViewGroup1.Name = "listViewGroup1";
            listViewGroup2.Header = "Результат";
            listViewGroup2.Name = "listViewGroup2";
            this.leaderBoard.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1,
            listViewGroup2});
            this.leaderBoard.HideSelection = false;
            this.leaderBoard.Location = new System.Drawing.Point(3, 3);
            this.leaderBoard.Name = "leaderBoard";
            this.leaderBoard.ShowGroups = false;
            this.leaderBoard.Size = new System.Drawing.Size(370, 405);
            this.leaderBoard.TabIndex = 0;
            this.leaderBoard.UseCompatibleStateImageBehavior = false;
            this.leaderBoard.View = System.Windows.Forms.View.Details;
            // 
            // leadersButton
            // 
            this.leadersButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(250)))), ((int)(((byte)(224)))));
            this.leadersButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.leadersButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leadersButton.Location = new System.Drawing.Point(140, 429);
            this.leadersButton.Name = "leadersButton";
            this.leadersButton.Size = new System.Drawing.Size(114, 34);
            this.leadersButton.TabIndex = 4;
            this.leadersButton.Text = "Закрыть";
            this.leadersButton.UseVisualStyleBackColor = false;
            this.leadersButton.Click += new System.EventHandler(this.leadersButton_Click);
            // 
            // loadManager
            // 
            this.loadManager.Enabled = false;
            this.loadManager.Location = new System.Drawing.Point(400, 187);
            this.loadManager.Name = "loadManager";
            this.loadManager.Size = new System.Drawing.Size(100, 96);
            this.loadManager.TabIndex = 5;
            this.loadManager.Text = "";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Лидеры";
            this.columnHeader1.Width = 350;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(108)))), ((int)(((byte)(37)))));
            this.ClientSize = new System.Drawing.Size(397, 467);
            this.Controls.Add(this.loadManager);
            this.Controls.Add(this.leadersButton);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView leaderBoard;
        private System.Windows.Forms.Button leadersButton;
        private System.Windows.Forms.RichTextBox loadManager;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}