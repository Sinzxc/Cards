﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void leadersButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            bool fileCheck = false;
            try 
            {
                loadManager.LoadFile("Leaderboard.rtf");
            }
            catch 
            {
                fileCheck = true;
                leaderBoard.Items.Add(new ListViewItem("Здесь пока пусто"));
            }
            if (!fileCheck) 
            {
                for (int i = 0; i < loadManager.Lines.Length; i++)
                {
                    leaderBoard.Items.Add(new ListViewItem(loadManager.Lines[i]));
                }
            }
        }
    }
}
