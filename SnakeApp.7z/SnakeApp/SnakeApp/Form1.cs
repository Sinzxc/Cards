﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Drawing.Imaging; // add this for the JPG compressor

namespace Snake
{
    public partial class Form1 : Form
    {

        private List<Section> Snake = new List<Section>();
        private Section food = new Section();

        int maxWidth;
        int maxHeight;

        int score;
        int highScore;

        Random rand = new Random();

        bool goLeft, goRight, goDown, goUp;

        int SectionWidth = 20,
        SectionHeigth = 20;
        string directions = "left";

        string PlayerName="test";


        public Form1(string name)
        {
            InitializeComponent();
            PlayerName = name;
        }
        
        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Left && directions != "right")|| (e.KeyCode == Keys.A && directions != "right"))
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right && directions != "left" || (e.KeyCode == Keys.D && directions != "left"))
            {
                goRight = true;
            }
            if (e.KeyCode == Keys.Up && directions != "down" || (e.KeyCode == Keys.W && directions != "down"))
            {
                goUp = true;
            }
            if (e.KeyCode == Keys.Down && directions != "up" || (e.KeyCode == Keys.S && directions != "up"))
            {
                goDown = true;
            }



        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left|| e.KeyCode == Keys.A)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.W)
            {
                goUp = false;
            }
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.S)
            {
                goDown = false;
            }
        }

        private void StartGame(object sender, EventArgs e)
        {
            RestartGame();
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            if (goLeft)
            {
                directions = "left";
            }
            if (goRight)
            {
                directions = "right";
            }
            if (goDown)
            {
                directions = "down";
            }
            if (goUp)
            {
                directions = "up";
            }


            for (int i = Snake.Count - 1; i >= 0; i--)
            {
                if (i == 0)
                {

                    switch (directions)
                    {
                        case "left":
                            Snake[i].X--;
                            break;
                        case "right":
                            Snake[i].X++;
                            break;
                        case "down":
                            Snake[i].Y++;
                            break;
                        case "up":
                            Snake[i].Y--;
                            break;
                    }

                    if (Snake[i].X < 0)
                    {
                        Snake[i].X = maxWidth;
                    }
                    if (Snake[i].X > maxWidth)
                    {
                        Snake[i].X = 0;
                    }
                    if (Snake[i].Y < 0)
                    {
                        Snake[i].Y = maxHeight;
                    }
                    if (Snake[i].Y > maxHeight)
                    {
                        Snake[i].Y = 0;
                    }


                    if (Snake[i].X == food.X && Snake[i].Y == food.Y)
                    {
                        EatFood();
                    }

                    for (int j = 1; j < Snake.Count; j++)
                    {

                        if (Snake[i].X == Snake[j].X && Snake[i].Y == Snake[j].Y)
                        {
                            GameOver();
                        }

                    }


                }
                else
                {
                    Snake[i].X = Snake[i - 1].X;
                    Snake[i].Y = Snake[i - 1].Y;
                }
            }
        }

        private void FrameUpdateTimer_Tick(object sender, EventArgs e)
        {
            GamePanel.Invalidate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.StartPosition = FormStartPosition.CenterParent;
            form2.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
            
        }

        private void UpdatePictureBoxGraphics(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            Brush snakeColour;
            Brush bodyColor = new SolidBrush(Color.FromArgb(96, 108, 56));
            Brush headColor = new SolidBrush(Color.FromArgb(40, 54, 24));
            for (int i = 0; i < Snake.Count; i++)
            {
                if (i == 0)
                {
                    snakeColour = headColor;
                }
                else
                {
                    snakeColour = bodyColor;
                }

                g.FillRectangle(snakeColour, new Rectangle
                    (
                    Snake[i].X * SectionWidth,
                    Snake[i].Y * SectionHeigth,
                    SectionWidth, SectionHeigth
                    ));
            }


            g.FillEllipse(Brushes.DarkRed, new Rectangle
            (
            food.X * SectionWidth,
            food.Y * SectionHeigth,
            SectionWidth, SectionHeigth
            ));
        }

        private void RestartGame()
        {
            maxWidth = GamePanel.Width / SectionWidth - 1;
            maxHeight = GamePanel.Height / SectionHeigth - 1;

            Snake.Clear();

            startButton.Enabled = false;
            leadersButton.Enabled = false;
            score = 0;
            txtScore.Text = "Счёт: " + score;

            Section head = new Section { X = 10, Y = 5 };
            Snake.Add(head); 

            for (int i = 0; i < 2; i++)
            {
                Section body = new Section();
                Snake.Add(body);
            }

            food = new Section { X = rand.Next(2, maxWidth), Y = rand.Next(2, maxHeight)};

            gameTimer.Start();

        }

        private void EatFood()
        {
            score += 1;

            txtScore.Text = "Счёт: " + score;

            Section body = new Section
            {
                X = Snake[Snake.Count - 1].X,
                Y = Snake[Snake.Count - 1].Y
            };

            Snake.Add(body);

            food = new Section { X = rand.Next(2, maxWidth), Y = rand.Next(2, maxHeight) };

            if(score%10==0)
                gameTimer.Interval-= 10;
        }

        private void GameOver()
        {
            gameTimer.Stop();
            startButton.Enabled = true;
            leadersButton.Enabled = true;
            if (score > highScore)
            {
                highScore = score;
                txtHighScore.Text = "Лучший результат: " + highScore;
            }

            try
            {
                saveManager.LoadFile("Leaderboard.rtf");
                saveManager.Text += "Имя: " + PlayerName + " Счёт:" + highScore.ToString() + "\n";
                saveManager.SaveFile("Leaderboard.rtf");
            }
            catch
            {
                saveManager.Text += "Имя: " + PlayerName + ", счёт:" + highScore.ToString() + "\n";
                saveManager.SaveFile("Leaderboard.rtf");
            }
        }


    }
    class Section
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Section()
        {
            X = 0;
            Y = 0;
        }


    }
}
