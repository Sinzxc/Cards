﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEst
{
    public partial class Form3 : Form
    {
        byte[] data;
        string mes;
        int answers, lenght;
        string fio;
        Form2 ff2;
        public Form3(byte[] data, int answers, int lenght,Form2 form2)
        {
            InitializeComponent();
            this.data = data;
            this.answers = answers;
            this.lenght = lenght;
            this.ff2 = form2;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label3.Text = ff2.textBox1.Text;
            label2.Text = $"Ваш результат {answers} из {lenght}";
            double ocenivanie = (double)answers / (double)lenght;
            if (ocenivanie < 0.5)
                mes = "Плохо";
            if (ocenivanie >= 0.5)
                mes = "Удовлитворительно";
            if (ocenivanie >= 0.7)
                mes = "Хорошо";
            if (ocenivanie >= 0.85)
                mes = "Отлично";
            label1.Text = mes;

        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void clsdBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void hideBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            panel1.Capture = false;
            Message m = Message.Create(Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            WndProc(ref m);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
