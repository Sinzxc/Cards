﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEst
{
    public partial class Form3 : Form
    {
        byte[] data;
        string mes;
        int answers, lenght;
        public Form3(byte[] data, int answers, int lenght)
        {
            InitializeComponent();
            this.data = data;
            this.answers = answers;
            this.lenght = lenght;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label2.Text = $"Ваш результат {answers} из {lenght}";
            double ocenivanie = (double)answers / (double)lenght;
            if (ocenivanie < 0.5)
                mes = "Плохо";
            if (ocenivanie >= 0.5)
                mes = "Удовлитворительно";
            if (ocenivanie >= 0.7)
                mes = "Хорошо";
            if (ocenivanie >= 0.85)
                mes = "Отлично";
            label1.Text = mes;
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
