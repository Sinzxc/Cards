﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEst
{
    public partial class Form2 : Form
    {
        string rb1, rb2, rb3, rb4;
        int questions = 0, i = 0;
        byte[] data = new byte[100];
        int counter = 0;
        public int answers;
        string correct;
        string s;
        string[] str;
        double ocenka;
        string mes;
        int lenght;
        string fio;
        public void Check()
        {
            if (radioButton1.Checked)
            {
                s = radioButton1.Text;
            }

            if (radioButton2.Checked)
            {
                s = radioButton2.Text;
            }

            if (radioButton3.Checked)
            {
               s = radioButton3.Text;
            }

            if (radioButton4.Checked)
            {
                s = radioButton4.Text;
            }
            int j = 0;
            while (j<4)
            {
               
                if(str[questions + j].Contains('+'))
                    correct = str[questions + j].Remove(0,1);
                j++;
            }
            if (s ==correct)
            {
                answers++;
                data[answers] = 1;
            }
        }
        public void ShowAnswer()
        {
            richTextBox1.Text = str[questions];
            radioButton1.Text = str[questions + 1].Remove(0 ,1);
            radioButton2.Text = str[questions + 2].Remove(0 ,1);
            radioButton3.Text = str[questions + 3].Remove(0, 1);
            radioButton4.Text = str[questions + 4].Remove(0, 1);
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            
            Check();
            lenght = str.Length / 5;
            if (questions + 10 < str.Length)
                questions += 5;
            else
            {
                Form3 form3 = new Form3(data,answers,lenght,this);
                form3.ShowDialog();

            }
            ShowAnswer();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            panel1.Capture = false;
            Message m = Message.Create(Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            WndProc(ref m);
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            f1.Show();
        }

        Form1 f1;
        public Form2(Form1 frm1)
        {
            InitializeComponent();
            this.f1 = frm1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Text = f1.textBox1.Text+" "+f1.textBox2.Text;
            textBox2.Text = f1.comboBox1.Text+ " " + f1.comboBox2.Text;
            try
            {
                richTextBox1.LoadFile("answers.rtf");
                str = richTextBox1.Lines;
                ShowAnswer();
                richTextBox1.Text = str[questions];
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
