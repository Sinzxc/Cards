﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Карты_Фаро
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            var startingDeck = from s in Suits()
                               from r in Ranks()
                               select new { Suit = s, Rank = r };

            foreach (var c in startingDeck)
            {
                Console.WriteLine(c);
            }

            var top = startingDeck.Take(26);
            var bottom = startingDeck.Skip(26);
            var shuffle = top.InterleaveSequenceWith(bottom);

            foreach (var c in shuffle)
            {
                Console.WriteLine(c);
            }

            var times = 0;

            shuffle = startingDeck;
            do
            {
                shuffle = shuffle.Take(26).InterleaveSequenceWith(shuffle.Skip(26));

                foreach (var card in shuffle)
                {
                    Console.WriteLine(card);
                }
                Console.WriteLine();
                times++;

            } while (!startingDeck.SequenceEquals(shuffle));

            Console.WriteLine(times);
            Console.ReadLine();
        }

        static IEnumerable<string> Suits()
        {
            yield return "Трефы";
            yield return "Бубны";
            yield return "Черви";
            yield return "Пики";
        }
        static IEnumerable<string> Ranks()
        {
            yield return "Двойка";
            yield return "Тройка";
            yield return "Четверка";
            yield return "Пятерка";
            yield return "Шестерка";
            yield return "Семерка";
            yield return "Восьмерка";
            yield return "Девятка";
            yield return "Десятка";
            yield return "Валет";
            yield return "Королева";
            yield return "Король";
            yield return "Туз";
        }

        public static bool SequenceEquals<T>
    (this IEnumerable<T> first, IEnumerable<T> second)
        {
            var firstIter = first.GetEnumerator();
            var secondIter = second.GetEnumerator();

            while (firstIter.MoveNext() && secondIter.MoveNext())
            {
                if (!firstIter.Current.Equals(secondIter.Current))
                {
                    return false;
                }
            }

            return true;

        }


    }
}
