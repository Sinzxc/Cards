﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using System.Collections.Generic;
using Word = Microsoft.Office.Interop.Word;


namespace MsOffice
{
    public partial class ThisAddIn
    {
        public void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            var bankAccounts = new List<Account>
            {
                new Account
                {
                    ID = 345,
                    Balance = 541.27
                },
                new Account
                {
                    ID = 123,
                    Balance = -127.44
                }
            };

            DisplayInExcel(bankAccounts, (account, cell) =>
            // This multiline lambda expression sets custom processing rules
            // for the bankAccounts.
            {
                cell.Value = account.ID;
                cell.Offset[0, 1].Value = account.Balance;
                if (account.Balance < 0)
                {
                    cell.Interior.Color = 255;
                    cell.Offset[0, 1].Interior.Color = 255;
                }
            });

            var wordApp = new Word.Application();
            wordApp.Visible = true;
            wordApp.Documents.Add();
            wordApp.Selection.PasteSpecial(Link: true, DisplayAsIcon: true);

        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        void DisplayInExcel(IEnumerable<Account> accounts, Action<Account, Excel.Range> DisplayFunc)
        {
            // Получаем объект приложения Excel
            var excelApp = this.Application;
            // Добавляем новую книгу Excel.
            excelApp.Workbooks.Add();
            // Отображаем окно Excel
            excelApp.Visible = true;
            // Занесение в указанный диапазон ячеек значения. Обращаемся к одной ячейке по имени.
            excelApp.Range["A1"].Value = "ID";
            excelApp.Range["B1"].Value = "Balance";
            // Делаем активной (выделяем) ячейку с именем «А2»
            excelApp.Range["A2"].Select();

            foreach (var ac in accounts)
            {
                // Выполняем функцию, которая задана делегатом DisplayFunc
                DisplayFunc(ac, excelApp.ActiveCell);
                // Делаем активной ячейку на одну строку ниже текущей активной ячейки
                excelApp.ActiveCell.Offset[1, 0].Select();
            }
            // Копируем результаты в буфер обмена.
            excelApp.Range["A1:B3"].Copy();

            //excelApp.Columns[1].AutoFit();
            //excelApp.Columns[2].AutoFit();


        }
        #region Код, автоматически созданный VSTO

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
