﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MsOffice
{
    class Account
    {
        public int ID { get; set; }
        public double Balance { get; set;}
  
    }
}
